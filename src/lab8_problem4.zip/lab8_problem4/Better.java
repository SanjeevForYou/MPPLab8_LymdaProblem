package lab8_problem4;

public class Better {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
